"""
Cira 

A simpler libray for alpaca-trade-api from Alpaca Markets.
"""

__version__ = "0.0.1"
__author__ = 'Axel Gard'
__credits__ = 'alpacahq markets'

